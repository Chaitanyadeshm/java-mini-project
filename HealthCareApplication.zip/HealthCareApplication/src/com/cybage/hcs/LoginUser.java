package com.cybage.hcs;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.modal.Users;
import com.cybage.service.HCSService;
import com.cybage.service.HCSServiceImpl;

/**
 * Servlet implementation class LoginUser
 */
@WebServlet("/LoginUser")
public class LoginUser extends HttpServlet {
	HCSService service = new HCSServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		Users user = service.loginUser(email, password);
		ServletContext context = getServletContext();
		if(user != null) {
			context.setAttribute("userRoleId", user.getRoleId());
			context.setAttribute("userId", user.getUserId());
			response.sendRedirect("IndexHome");
		}else {
			context.setAttribute("error_login", "Invalid email or password");
			response.sendRedirect("login.jsp");
			
		}

	}

}
