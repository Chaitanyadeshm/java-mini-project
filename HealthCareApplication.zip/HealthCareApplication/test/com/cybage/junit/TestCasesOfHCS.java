package com.cybage.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.cybage.modal.AllUsers;
import com.cybage.modal.Appointment;
import com.cybage.modal.DetailedAppointment;
import com.cybage.modal.Doctor;
import com.cybage.modal.Roles;
import com.cybage.modal.Specialization;
import com.cybage.modal.Users;
import com.cybage.service.HCSService;
import com.cybage.service.HCSServiceImpl;

public class TestCasesOfHCS {
	HCSService service = new HCSServiceImpl();

	/*
	 *	List<Roles> getAllRoles();
	List<Specialization> getAllSpecialization();
	List<Users> getSpecificUsers(String typeOfUser);
	boolean registerDoctor(Users user, String[] doctorsSpecialization) throws ClassNotFoundException, SQLException;
	List<AllUsers> getAllUsers();
	List<String> getDoctorsSpecializations(int doctordId);
	List<DetailedAppointment> getALlDetailedAppointments(int roleId, int userId);
	boolean updateAppointmentStatus(int appointmentId, String status);
	boolean registerPatient(Users user);
	List<Doctor> getSpecializedDoctor(int specializationId);
	List<Appointment> getDoctorsAppointment(int doctorId);
	Users getUserById(int userId);
	boolean updateUser(Users user);
	boolean changePassword(int userId, String newPassword);
	boolean addPrescription(int appointmentId, String prescriptionText);
	boolean addFeedback(int appointmentId, String enteredText);
	*/
	@Test
	void testUserLogin() {
		Users user = service.loginUser("ray@cybage.com", "admin@123");
		int roleId = user.getRoleId();
		assertEquals(1, roleId);
	}
	@Test
	void testGetUserById() {
		Users user = service.getUserById(1);
		String email = user.getEmail();
		assertEquals("chaitanya@cybage.com", email);
	}
	@Test
	void testGetAllUsers() {
		List<AllUsers> users = service.getAllUsers();
		String email = users.get(1).getEmail();
		assertEquals("swaraj@cybage.com", email);
	}
	
	
//	@Test
//	void testAddAppointment() {
//		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
//		java.util.Date date = null;
//		Time sqlTime = null;
//		try {
//			date = sdf1.parse("2022-12-25");
//			sqlTime = Time.valueOf("18:00:00");
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
//		Appointment appointment = new Appointment();
//		appointment.setPatientId(2);
//		appointment.setDoctorId(3);
//		appointment.setAppointmentTime(sqlTime);
//		appointment.setAppointmentDate(sqlDate);
//		appointment.setPatientsNotes("notes from test case");
//		boolean success = service.addAppointment(appointment);
//		assertTrue(success);
//	}
	
}
