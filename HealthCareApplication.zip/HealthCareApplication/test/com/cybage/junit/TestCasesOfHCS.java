package com.cybage.junit;

import org.junit.jupiter.api.Test;

import com.cybage.dao.HCSDAO;
import com.cybage.dao.HCSDAOImpl;
import com.cybage.service.HCSService;
import com.cybage.service.HCSServiceImpl;

public class TestCasesOfHCS {
	HCSService service = new HCSServiceImpl();
	@Test
	void testString() {
//		assertFalse(mathOperations.stringLength("this "));
	}
}
